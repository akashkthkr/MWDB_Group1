import numpy as np

from services.similarities import CosineSimilarity, ChiSquareSimilarity, LNormSimilarity
from utilities import MergeFeatures


def get_weighted_similarity(color_moment, elbp, hog):
    w1, w2, w3 = 0.34, 0.33, 0.33
    return (w1 * color_moment + w2 * elbp + w3 * hog)
def get_merged_similarities(features):
    result_dict = {}
    for image in features:
        for inner_image in features:
            merged_features = MergeFeatures.get_merged_feature_list(features)
            color_moment = CosineSimilarity.get_cosine_similarity(np.array(merged_features[image]),
                                               np.array(merged_features[inner_image]))
            elbp = ChiSquareSimilarity.get_chi_square_similarity(np.array(features[image]["ELBP"]),
                                                                  np.array(features[inner_image]["ELBP"]))
            hog = LNormSimilarity.get_l_norm_similarity(np.array(features[image]["HOG"]),
                                                                  np.array(features[inner_image]["HOG"]))

            result = get_weighted_similarity(color_moment, elbp, hog)
            result_dict[inner_image] = result
            # print(result)
        sorted_result = sorted(result_dict, key=result_dict.get)
        print(sorted_result)